//
//  NamePage.swift
//  TZBALINASOFT
//
//  Created by Родион Ковалевский on 2/15/20.
//  Copyright © 2020 Родион Ковалевский. All rights reserved.
//

import Foundation
struct Page: Decodable {
    var page: Int?
    var pageSize: Int?
    var totalPages : Int?
    var totalElements: Int?
    var content: [Content]?
}

struct Content: Decodable {
    var id: Int?
    var name: String?
}

