//
//  post.swift
//  TZBALINASOFT
//
//  Created by Родион Ковалевский on 2/17/20.
//  Copyright © 2020 Родион Ковалевский. All rights reserved.
//
import UIKit
import Foundation
 

struct Post:Decodable {
    var id: Int
    var name: String
    var image:String
    init(id:Int,name:String,image:String) {
        self.id = id
        self.name = name
        self.image = image
    }
    }

