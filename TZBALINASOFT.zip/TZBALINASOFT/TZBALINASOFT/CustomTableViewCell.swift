//
//  Cell.swift
//  TZBALINASOFT
//
//  Created by Родион Ковалевский on 2/15/20.
//  Copyright © 2020 Родион Ковалевский. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
   
         
}
