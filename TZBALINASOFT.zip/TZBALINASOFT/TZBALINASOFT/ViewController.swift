//
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var cellCount = 0
    var idArray:[Int] = []
    var nameArray:[String] = []
    var image:UIImage?
    var cell:Int = 0
    let imagePicker = UIImagePickerController()
    var postObject:Post?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.imagePicker.delegate = self
        Manager.shared.updateInfo { (page, error) in
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            if let page = page{
                self.cellCount =  page.content?.count ?? 0
                    for element in page.content!{
                    self.idArray.append(element.id!)
                    self .nameArray.append(element.name!)
                }
            }
        }
    }
    func pickLibrary(){
    self.imagePicker.sourceType = .photoLibrary
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    
        
    
    func pickWithCamera(){
        self.imagePicker.sourceType = .camera
        self.imagePicker.allowsEditing = true
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    func alert() {
        let alert = UIAlertController(title: "Choose" , message:nil , preferredStyle: .actionSheet)
        let libraryAction = UIAlertAction(title: "library" , style: .default, handler: {(alert) in self.pickLibrary()})
        let cameraAction = UIAlertAction(title: "camera" , style: .default, handler: {(alert) in self.pickWithCamera()})
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel)
        alert.addAction(libraryAction)
        alert.addAction(cameraAction)
        alert.addAction(cancelAction)
        self.present(alert, animated:true, completion: nil)

    }

    
    
    
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CustomTableViewCell
        cell.idLabel.text = String(idArray[indexPath.row])
        cell.nameLabel.text = String(nameArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cell = indexPath.row
        alert()
    }
}
extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            image = pickedImage
            self.imagePicker.dismiss(animated: true)
            let strBase64 =  (image!.pngData()?.base64EncodedString())!
            let obj = Post(id: cell, name: "Rodion Kovalevsky", image: strBase64)
           Manager.shared.post(object: obj)
        }
    }
}

