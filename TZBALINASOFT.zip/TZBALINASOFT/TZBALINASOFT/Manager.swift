//
//  Manager.swift
//  TZBALINASOFT
//
//  Created by Родион Ковалевский on 2/15/20.
//  Copyright © 2020 Родион Ковалевский. All rights reserved.
//

import Foundation
class Manager  {
    static let shared = Manager()
    init() {}
    var page = Page()
    
    func updateInfo(handler: @escaping(_ page: Page?, _ error: Error?)->()) {
        var page = Page()
        let session = URLSession.shared
        guard let url = URL(string: "https://junior.balinasoft.com/api/v2/photo/type") else {
            return
        }
        let task = session.dataTask(with: url) { (data, response, error) in
            guard error == nil else {
                print("\(error!.localizedDescription)")
                return
            }
            
            do {
                self.page = try JSONDecoder().decode(Page.self, from: data!)
                handler(self.page, nil)
            } catch let error{
                handler(nil, error)
            }
        }
        task.resume()
        
    }
    
    func post(object:Post){
        print("entry point post")
        guard let url = URL(string: "https://junior.balinasoft.com/api/v2/photo") else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: object, options:[]) else {return}
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data,response,error) in
            if let response = response{
            print(response)
        }
        guard let data = data else {return}
        do{
            let json = try JSONSerialization.jsonObject(with: data, options: [])
            print(json)
        } catch{
            print(error)
            }
        }.resume()


}

}



